import React, { useEffect, useState } from "react";
import { Edit } from "@refinedev/mui";
import { useForm } from "@refinedev/react-hook-form";
import { useOne, useList } from "@refinedev/core";
import {
  Box,
  TextField,
  Switch,
  FormControlLabel,
  Button,
  Grid,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Paper,
  Checkbox,
  IconButton,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Typography,
  InputAdornment,
} from "@mui/material";
import { useNavigate, useParams } from "react-router-dom";
import { Controller } from "react-hook-form";
import SaveIcon from '@mui/icons-material/Save';
import ClearIcon from '@mui/icons-material/Clear';
import CancelIcon from '@mui/icons-material/Cancel';
import DeleteIcon from '@mui/icons-material/Delete';
import SearchIcon from '@mui/icons-material/Search';
import AddIcon from '@mui/icons-material/Add';

export const GroupEdit = () => {
  const { id } = useParams();
  const navigate = useNavigate();

  // Buscando os dados do grupo
  const { data: groupData, isLoading: isLoadingGroup } = useOne({
    resource: "groups",
    id: id as string,
  });

  // Inicializando o formulário com useForm
  const {
    saveButtonProps,
    refineCore: { onFinish },
    register,
    control,
    formState: { errors },
    reset,
    handleSubmit, // Adicionando handleSubmit aqui
  } = useForm();

  // Estados para gerenciar as pessoas selecionadas e o diálogo
  const [selectedPeople, setSelectedPeople] = useState<any[]>([]);
  const [searchTerm, setSearchTerm] = useState("");
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [dialogSelectedPeople, setDialogSelectedPeople] = useState<any[]>([]);
  const [dialogSearchTerm, setDialogSearchTerm] = useState("");

  // Buscando todos os dados de pessoas
  const { data: allPeopleData, isLoading: isLoadingPeople } = useList({
    resource: "people",
  });

  // Efeito para definir valores iniciais do formulário
  useEffect(() => {
    if (groupData?.data) {
      const group = groupData.data;
      reset({
        description: group.description, // Mudança de "name" para "description"
        ignoreAntiDoubleEntry: group.ignoreAntiDoubleEntry,
      });
      setSelectedPeople(group.people || []); // Preencher o estado com pessoas do grupo
    }
  }, [groupData, reset]);

  // Funções de manipulação
  const handleClear = () => {
    reset({ description: "", ignoreAntiDoubleEntry: false });
    setSelectedPeople([]);
  };

  const handleCancel = () => {
    navigate("/groups");
  };

  const handlePersonRemove = (personId: string) => {
    setSelectedPeople(prev => prev.filter(person => person.id !== personId));
  };

  const handleDialogOpen = () => {
    setIsDialogOpen(true);
    setDialogSelectedPeople([]); // Limpar seleção no diálogo ao abrir
  };

  const handleDialogClose = () => {
    setIsDialogOpen(false);
    setDialogSearchTerm("");
  };

  const handleDialogSave = () => {
    // Adicionar pessoas selecionadas ao grupo
    setSelectedPeople(prev => {
      const newSelection = [...prev, ...dialogSelectedPeople];
      return Array.from(new Set(newSelection.map(a => a.id)))
        .map(id => newSelection.find(a => a.id === id));
    });
    handleDialogClose();
  };

  const handleDialogPersonToggle = (person: any) => {
    setDialogSelectedPeople(prev =>
      prev.some(p => p.id === person.id)
        ? prev.filter(p => p.id !== person.id)
        : [...prev, person]
    );
  };

  const handleSelectAll = (select: boolean) => {
    if (select) {
      setDialogSelectedPeople(filteredAllPeople);
    } else {
      setDialogSelectedPeople([]);
    }
  };

  // Função para lidar com o envio do formulário
  const onSubmit = async (data: any) => {
    const updatedData = {
      ...data,
      people: selectedPeople.map(p => p.id),
    };
    
    try {
      const result = await onFinish(updatedData);
      console.log("Dados salvos com sucesso:", result);
    } catch (error) {
      console.error("Erro ao salvar os dados:", error);
    }
  };

  // Filtrando pessoas
  const filteredSelectedPeople = selectedPeople.filter(person =>
    person.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    person.email.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const filteredAllPeople = allPeopleData?.data?.filter(person =>
    !selectedPeople.some(p => p.id === person.id) &&
    (person.name.toLowerCase().includes(dialogSearchTerm.toLowerCase()) ||
    person.email.toLowerCase().includes(dialogSearchTerm.toLowerCase()))
  ) || [];

  if (isLoadingGroup || isLoadingPeople) {
    return <div>Carregando...</div>;
  }

  return (
    <Edit saveButtonProps={{ onClick: handleSubmit(onSubmit) }}> {/* Alteração aqui */}
      <Box component="form" sx={{ display: "flex", flexDirection: "column" }} autoComplete="off">
        <Grid container spacing={2}>
          <Grid item xs={12} md={6}>
            <TextField
              {...register("description", { required: "Por favor, preencha a descrição!" })}
              error={!!errors.description}
              helperText={errors.description?.message}
              margin="normal"
              fullWidth
              InputLabelProps={{ shrink: true }}
              label="Descrição" 
              name="description"
            />
          </Grid>
          <Grid item xs={12} md={6} sx={{ display: 'flex', alignItems: 'center', justifyContent: 'flex-end' }}>
            <Controller
              control={control}
              name="ignoreAntiDoubleEntry"
              render={({ field }) => (
                <FormControlLabel
                  control={
                    <Switch
                      {...field}
                      checked={field.value}
                      onChange={(e) => field.onChange(e.target.checked)}
                    />
                  }
                  label="Ignorar Anti Dupla Entrada"
                />
              )}
            />
          </Grid>
        </Grid>

        {/* Seção de Pessoas Associadas */}
        <Box mt={4}>
          <Grid container justifyContent="space-between" alignItems="center" mb={2}>
            <Grid item>
              <Typography variant="h6">Pessoas associadas ao Grupo</Typography>
            </Grid>
            <Grid item>
              <TextField
                variant="outlined"
                placeholder="Pesquisar..."
                onChange={(e) => setSearchTerm(e.target.value)}
                InputProps={{
                  endAdornment: (
                    <InputAdornment position="end">
                      <SearchIcon />
                    </InputAdornment>
                  ),
                }}
              />
            </Grid>
          </Grid>

          <TableContainer component={Paper}>
            <Table>
              <TableHead>
                <TableRow>
                  <TableCell><strong>Nome</strong></TableCell>
                  <TableCell><strong>E-mail</strong></TableCell>
                  <TableCell align="right"><strong>Ações</strong></TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {filteredSelectedPeople.map((person) => (
                  <TableRow key={person.id}>
                    <TableCell>{person.name}</TableCell>
                    <TableCell>{person.email}</TableCell>
                    <TableCell align="right">
                      <IconButton onClick={() => handlePersonRemove(person.id)}>
                        <DeleteIcon />
                      </IconButton>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </TableContainer>

          <Button
            variant="outlined"
            startIcon={<AddIcon />}
            onClick={handleDialogOpen}
            sx={{ mt: 2 }}
          >
            Adicionar Pessoas
          </Button>
        </Box>

        {/* Diálogo para adicionar pessoas */}
        <Dialog open={isDialogOpen} onClose={handleDialogClose}>
          <DialogTitle>Adicionar Pessoas ao Grupo</DialogTitle>
          <DialogContent>
            <TextField
              placeholder="Pesquisar..."
              fullWidth
              onChange={(e) => setDialogSearchTerm(e.target.value)}
              InputProps={{
                endAdornment: (
                  <InputAdornment position="end">
                    <SearchIcon />
                  </InputAdornment>
                ),
              }}
            />
            <TableContainer component={Paper} sx={{ mt: 2 }}>
              <Table>
                <TableHead>
                  <TableRow>
                    <TableCell>
                      <Checkbox
                        checked={dialogSelectedPeople.length === filteredAllPeople.length && filteredAllPeople.length > 0}
                        onChange={(e) => handleSelectAll(e.target.checked)}
                      />
                    </TableCell>
                    <TableCell><strong>Nome</strong></TableCell>
                    <TableCell><strong>E-mail</strong></TableCell>
                  </TableRow>
                </TableHead>
                <TableBody>
                  {filteredAllPeople.map((person) => (
                    <TableRow key={person.id}>
                      <TableCell>
                        <Checkbox
                          checked={dialogSelectedPeople.some(p => p.id === person.id)}
                          onChange={() => handleDialogPersonToggle(person)}
                        />
                      </TableCell>
                      <TableCell>{person.name}</TableCell>
                      <TableCell>{person.email}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </TableContainer>
          </DialogContent>
          <DialogActions>
            <Button onClick={handleDialogClose} startIcon={<CancelIcon />}>Cancelar</Button>
            <Button onClick={handleDialogSave} startIcon={<SaveIcon />}>Salvar</Button>
          </DialogActions>
        </Dialog>
      </Box>
    </Edit>
  );
};
