import { MuiShowInferencer } from "@refinedev/inferencer/mui";

export const GroupShow = () => {
  return <MuiShowInferencer />;
};