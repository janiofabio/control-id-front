/* import { MuiListInferencer } from "@refinedev/inferencer/mui";

export const GroupList = () => {
  return <MuiListInferencer />;
};
*/

import React from "react";
import {
    useDataGrid,
    EditButton,
    ShowButton,
    DeleteButton,
    List,
    DateField,
} from "@refinedev/mui";
import { DataGrid, GridColDef } from "@mui/x-data-grid";
import { useMany } from "@refinedev/core";
import { Checkbox } from "@mui/material";

export const GroupList = () => {
    const { dataGridProps } = useDataGrid();

    const { data: groupData, isLoading: groupIsLoading } = useMany({
        resource: "groups",
        ids: dataGridProps?.rows?.map((item: any) => item?.groupID) ?? [],
        queryOptions: {
            enabled: !!dataGridProps?.rows,
        },
    });

    const columns = React.useMemo<GridColDef[]>(
        () => [
            {
                field: "id",
                headerName: "Id",
                type: "number",
                minWidth: 50,
            },
            {
                field: "description",
                flex: 1,
                headerName: "Description",
                minWidth: 200,
            },
            {
                field: "type",
                flex: 1,
                headerName: "Type",
                minWidth: 200,
            },
            {
                field: "maximumTime",
                flex: 1,
                headerName: "Maximum Time",
                minWidth: 200,
            },
            {
                field: "doubleEntry",
                headerName: "Double Entry",
                minWidth: 100,
                renderCell: function render({ value }) {
                    return <Checkbox checked={!!value} />;
                },
            },
            {
                field: "credit",
                headerName: "Credit",
                minWidth: 100,
                renderCell: function render({ value }) {
                    return <Checkbox checked={!!value} />;
                },
            },
            {
                field: "blacklist",
                headerName: "Blacklist",
                minWidth: 100,
                renderCell: function render({ value }) {
                    return <Checkbox checked={!!value} />;
                },
            },
            {
                field: "groupID",
                flex: 1,
                headerName: "Group",
                minWidth: 300,
            },
            {
                field: "GroupName",
                flex: 1,
                headerName: "Group Name",
                minWidth: 200,
            },
            {
                field: "tradeName",
                flex: 1,
                headerName: "Trade Name",
                minWidth: 200,
            },
            {
                field: "igonreAntiDoubleEntry",
                headerName: "Igonre Anti Double Entry",
                minWidth: 100,
                renderCell: function render({ value }) {
                    return <Checkbox checked={!!value} />;
                },
            },
            {
                field: "createdAt",
                flex: 1,
                headerName: "Created At",
                minWidth: 250,
                renderCell: function render({ value }) {
                    return <DateField value={value} />;
                },
            },
            {
                field: "updatedAt",
                flex: 1,
                headerName: "Updated At",
                minWidth: 250,
                renderCell: function render({ value }) {
                    return <DateField value={value} />;
                },
            },
            {
                field: "actions",
                headerName: "Actions",
                sortable: false,
                renderCell: function render({ row }) {
                    return (
                        <>
                            <EditButton hideText recordItemId={row.id} />
                            <ShowButton hideText recordItemId={row.id} />
                            <DeleteButton hideText recordItemId={row.id} />
                        </>
                    );
                },
                align: "center",
                headerAlign: "center",
                minWidth: 80,
            },
        ],
        [groupData?.data],
    );

    return (
        <List>
            <DataGrid {...dataGridProps} columns={columns} autoHeight />
        </List>
    );
};
