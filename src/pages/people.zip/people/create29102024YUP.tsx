import React, { useState } from "react";
import { useTranslate, useCreate, useNotification, useNavigation } from "@refinedev/core";
import { Create } from "@refinedev/mui";
import { useForm } from "@refinedev/react-hook-form";
import { Button, TextField, Box, Grid, Typography, Tab, Tabs, useTheme } from "@mui/material";
import { FormProvider } from "react-hook-form";
import GeralSection from "@components/GeralSection";
import AddInfoSection from "@components/AddInfoSection";
import DocumentSection from "@components/DocumentSection";
import GroupSection from "@components/GroupSection";
import PhotoCamera from '@mui/icons-material/PhotoCamera';
import PhoneInput from "react-phone-input-2";
import "react-phone-input-2/lib/style.css";
import LoadingButton from "@mui/lab/LoadingButton";
import { Controller } from "react-hook-form";
import { uploadFileToStrapi } from "../../utils/api";

import { yupResolver } from "@hookform/resolvers/yup";
import * as yup from "yup";
import { Person } from "../../utils/types";
import { useFileUpload } from "../../utils/useFileUpload";
import { useGroups } from "../../services/GroupContext";

const schema = yup.object().shape({
  name: yup.string().required("Nome é obrigatório"),
  email: yup.string().email("E-mail inválido").required("E-mail é obrigatório"),
  phoneNumber: yup.string().required("Número de telefone é obrigatório"),
  registration: yup.string(),
  iDSecureAccess: yup.boolean(),
  deviceAdmin: yup.boolean(),
  blockList: yup.boolean(),
  iDSecurePassword: yup.string().when("iDSecureAccess", {
    is: true,
    then: yup.string().required("Senha de iDSecure é obrigatória quando o acesso está ativado")
  }),
  accessProfile: yup.string().when("deviceAdmin", {
    is: true,
    then: yup.string().required("Perfil de acesso é obrigatório para administradores de dispositivo")
  }),
});

export const PersonCreate = () => {
  const translate = useTranslate();
  const { mutate: createPerson } = useCreate();
  const { open } = useNotification();
  const { push } = useNavigation();
  const { uploadFile, isUploading } = useFileUpload();
  const { availableGroups } = useGroups();

  const methods = useForm<Person>({
    resolver: yupResolver(schema),
    defaultValues: {
      iDSecureAccess: false,
      deviceAdmin: false,
      blockList: false,
      documents: [],
      groups: [],
    }
  });

  const {
    control,
    handleSubmit,
    formState: { errors },
    setValue,
    watch,
  } = methods;

  const theme = useTheme();
  const [tabValue, setTabValue] = React.useState(0);
  const imageInput = watch("personPhoto");

  const handleTabChange = (event: React.SyntheticEvent, newValue: number) => {
    setTabValue(newValue);
  };

  const onSubmit = async (data: Person) => {
    try {
      if (data.personPhoto) {
        const uploadedPhoto = await uploadFile(data.personPhoto as unknown as File);
        data.personPhoto = uploadedPhoto.url;
      }

      const processedDocuments = await Promise.all(data.documents.map(async (doc) => {
        if (doc.attachmentUrl) return doc;
        const uploadedFile = await uploadFile(doc as unknown as File);
        return {
          ...doc,
          attachmentUrl: uploadedFile.url,
          attachmentId: uploadedFile.id
        };
      }));

      data.documents = processedDocuments;

      createPerson({
        resource: "people",
        values: data,
      }, {
        onSuccess: () => {
          open({
            type: "success",
            message: "Pessoa criada com sucesso!",
          });
          push("/people");
        },
        onError: (error) => {
          console.error("Erro ao salvar pessoa:", error);
          open({
            type: "error",
            message: "Erro ao salvar pessoa. Por favor, tente novamente.",
          });
        }
      });
    } catch (error) {
      console.error("Erro ao processar dados:", error);
      open({
        type: "error",
        message: "Erro ao processar a solicitação. Por favor, tente novamente.",
      });
    }
  };

  return (
    <FormProvider {...methods}>
      <Create saveButtonProps={{ onClick: handleSubmit(onSubmit), disabled: isUploading }}>
        <Box sx={{ padding: 2 }}>
          <Typography variant="h6" gutterBottom>
            {translate("Criar Pessoa")}
          </Typography>

          <Grid container spacing={2}>
            {/* ... (código para upload de foto) */}

            <Grid item xs={12} md={9}>
              <Grid container spacing={2}>
                <Grid item xs={12} md={6}>
                  <Controller
                    name="name"
                    control={control}
                    render={({ field }) => (
                      <TextField
                        {...field}
                        label="Nome"
                        fullWidth
                        error={!!errors.name}
                        helperText={errors.name?.message}
                      />
                    )}
                  />
                </Grid>
                <Grid item xs={12} md={6}>
                  <Controller
                    name="email"
                    control={control}
                    render={({ field }) => (
                      <TextField
                        {...field}
                        label="E-mail"
                        fullWidth
                        error={!!errors.email}
                        helperText={errors.email?.message}
                      />
                    )}
                  />
                </Grid>
                {/* ... (outros campos) */}
              </Grid>
            </Grid>
          </Grid>

          <Box sx={{ borderBottom: 1, borderColor: "divider", mt: 2 }}>
            <Tabs value={tabValue} onChange={handleTabChange}>
              <Tab label="Geral" />
              <Tab label="Informações Adicionais" />
              <Tab label="Documentos" />
              <Tab label="Grupos" />
            </Tabs>
          </Box>

          <Box sx={{ mt: 2 }}>
            {tabValue === 0 && <GeralSection />}
            {tabValue === 1 && <AddInfoSection />}
            {tabValue === 2 && <DocumentSection />}
            {tabValue === 3 && <GroupSection availableGroups={availableGroups} />}
          </Box>
        </Box>
      </Create>
    </FormProvider>
  );
}