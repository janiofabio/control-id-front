// src/pages/people/index.ts
export { PersonCreate } from './create';
export { PersonEdit } from './edit';
export { PersonList } from './list';
export { PersonShow } from './show';
